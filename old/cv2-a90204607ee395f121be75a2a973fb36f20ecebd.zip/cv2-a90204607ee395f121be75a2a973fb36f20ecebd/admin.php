<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
    <title>Admin Login</title>
    
</head>
<body>
    <header>
        Admin Panel
    </header>
    <div>
        <Ul>
            <li><a href="http://localhost/cv/addHospital.html">Add New Hospital</a></li>
            <li><a href="http://localhost/cv/HcData.html">Update Healthcare data</a></li>
            <li><a href="http://localhost/cv/CaseData.html"> Update regional Cases</a></li>
        </Ul>
    </div>
</body>
</html>
