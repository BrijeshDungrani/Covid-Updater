<?php 
session_start();

	echo "<center>You are Successfully logout....!!!!!</center> ";
	include('login.php');
	   
?>